import VideoConferencing from "./VideoConferencing.jsx"

function App() {


  return (
    <>
     
   
      <VideoConferencing/>
    </>
  )
}

export default App
